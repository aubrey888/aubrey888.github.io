------------------------
HOW TO RUN
------------------------
Run: cd into the directory where main.py is located.
------------------------
DEPENDENCIES
------------------------
Must have python 3.10 or greater installed
------------------------
SUBMISSION INFORMATION
------------------------
Computational Foundations Spring 2024 Final Project
Author: Aubrey Hatch, Winnie Burke
Date: May 4, 2024
------------------------
ABOUT THIS PROJECT
------------------------
This project implements a game modeled after the daily life of a cat. The user is taken through four diffferent challanges. 
Challenge 1 is to catch 30 fish in 30 seconds. 
Challenge 2 is to catch 30 fish in 30 seconds while avoiding toxic pufferfish.
Challenge 3 is to catch the red laser within 30 seconds.
Challenge 4 is to avoid raindrops and stay dry for 30 seconds.
Then, the player is presented with the number of successfully completed challenges.
