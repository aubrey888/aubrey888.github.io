#include "board.h"
#include "candystore.h"
#include "player.h"
#include <cassert>


int main()
{
    Board board;
    board.displayBoard();

    Candy red = {"red", "red candy", 10, ""};
    Candy yellow = {"yellow", "yellow candy", 20, ""};
    Candy blue = {"blue", "blue candy", 30, ""};
    Candy green = {"green", "green candy", 40, ""};

    // Create candy stores
    CandyStore c1("Winnie's store"), c2("Bunny's store"), c3("Donald's store");
    assert(c1.addCandy(red));
    assert(c1.addCandy(yellow));
    assert(c2.addCandy(blue));
    assert(c3.addCandy(green));
    CandyStore candy_stores[] = {c1, c2, c3};

    // Set candy store locations
    assert(board.addCandyStore(20));
    assert(board.addCandyStore(35));
    assert(board.addCandyStore(50));

    for (int i = 0; i < board.getBoardSize(); i++)
    {
        board.setPlayerPosition(i);
        if (board.isPositionCandyStore(i))
        {
            board.displayBoard();
            int candy_store_idx = board.getCandyStoreIndex(i);
            candy_stores[candy_store_idx].displayCandies();
        }
    }

    return 0;
}
