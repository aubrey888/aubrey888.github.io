#include "player.h"
#include <iostream>



Player::Player() : _storename(""), _candy_count(0)
{
}

Player::Player(string player_name) : _player_name(player_name), _player_count(0)
{
}


