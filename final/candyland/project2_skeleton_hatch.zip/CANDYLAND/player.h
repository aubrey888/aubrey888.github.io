#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>
#include <vector>

using namespace std;

struct ThePlayer
{
    string name;
    int stamina;
    double gold;
    vector<string> candies;
};

class Player
{
private:
    string _storename;
    int _candy_count;

    string _player_name;
    int _player_count;

    int _player_stamina;
    int _player_skip_count;
    bool _player_can_move;

public:
    Player();
    Player(string player_name);

    int setPlayerStamina(int);
    int getPlayerStamina();

    int spendPlayerGold(int);
    int getPlayerGold();

    void removePlayerCandy(int); // index of the candy to remove.
    vector<string> getPlayerCandies();
};

#endif
