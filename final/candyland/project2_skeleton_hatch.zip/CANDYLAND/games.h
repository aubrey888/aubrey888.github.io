#ifndef GAMES_H
#define GAMES_H

#include <iostream>
#include <vector> // when implementing candy bet

using namespace std;

// rock paper scissors and riddle


class Games
{
private:
    string _player_name;

public:
    Games();
    void playRockPaperScissors(string player_name); // playing against the computer so only one player
    void solveRiddles(string player_name) ;

    bool isWinner;
};

#endif