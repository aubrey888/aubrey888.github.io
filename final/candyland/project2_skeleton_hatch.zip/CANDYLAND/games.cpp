#include <iostream>
#include <fstream>
#include <iomanip>
#include <cassert>
#include <cstring>
#include <vector>
#include "games.h"

using namespace std;


void playRockPaperScissors(string player_name) {

}

void solveRiddles(string player_name) {

    
}
