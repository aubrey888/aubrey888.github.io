// CandyStore.cpp

#include "candystore.h"
#include <iostream>

CandyStore::CandyStore() : _storename(""), _candy_count(0)
{
}

CandyStore::CandyStore(string store_name) : _storename(store_name), _candy_count(0)
{
}

bool CandyStore::addCandy(Candy candy)
{
    if (_candy_count >= _MAX_CANDIES)
    {
        return false;
    }
    _candies[_candy_count] = candy;
    _candy_count++;
    return true;
}

bool CandyStore::removeCandy(string candy_name)
{
    for (int i = 0; i < _candy_count; i++)
    {
        if (_candies[i].name == candy_name)
        {
            // Remove candy by shifting remaining candies
            for (int j = i; j < _candy_count - 1; j++)
            {
                _candies[j] = _candies[j + 1];
            }
            _candy_count--;
            return true;
        }
    }
    return false;
}

void CandyStore::displayCandies() const
{
    cout << "Candies in " << _storename << ":\n";
    for (int i = 0; i < _candy_count; i++)
    {
        cout << "Name: " << _candies[i].name << "\n";
        cout << "Description: " << _candies[i].description << "\n";
        cout << "Price: $" << _candies[i].price << "\n";
        cout << "Type: " << _candies[i].candy_type << "\n\n";
    }
}


